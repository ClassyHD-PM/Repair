<?php

namespace ClassyHD\RepairPlugin;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use pocketmine\event\Listener;

use jojoe77777\FormAPI\SimpleForm;
use onebone\economyapi\EconomyAPI;

class Main extends PluginBase implements Listener {

    private int $pricePerDamage = 20;

    public function onEnable(): void {
        $this->getLogger()->info("Tamir eklentisi aktif.");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if(strtolower($command->getName()) === "tamir" && $sender instanceof Player){
            $this->openRepairForm($sender);
            return true;
        }
        return false;
    }

    private function openRepairForm(Player $player): void {
        $item = $player->getInventory()->getItemInHand();

        if ($item->equals(VanillaItems::AIR())) {
            $player->sendMessage("§cElinde tamir edilebilir bir eşya yok!");
            return;
        }

        if ($item->getMaxDurability() <= 0) {
            $player->sendMessage("§cElindeki eşya tamir edilebilir değil!");
            return;
        }

        $damage = $item->getDamage();
        if($damage <= 0){
            $player->sendMessage("§aEşyan hasarsız, tamire gerek yok!");
            return;
        }

        $cost = $damage * $this->pricePerDamage;

        $money = EconomyAPI::getInstance()->myMoney($player);

        $form = new SimpleForm(function(Player $player, ?int $data) use ($cost) {
            if($data === null) return;
            if($data === 0){
                $this->processRepair($player, $cost);
            } else {
                $player->sendMessage("§cTamir işlemi iptal edildi.");
            }
        });

        $form->setTitle("Tamir Menüsü");
        $form->setContent(
            "§fHasar Başına Alınacak Fiyat: §a{$this->pricePerDamage}TL\n".
            "§fElindeki Eşyanın Hasarı: §a{$damage}\n".
            "§fEşyanın Tamir Ücreti: §a{$cost}TL\n".
            "§fMevcut Paran: §a{$money}TL\n\n".
            "§bTamir Etmek İster Misin?"
        );

        $form->addButton("§aTamir Et");
        $form->addButton("§cİptal Et");

        $player->sendForm($form);
    }

    private function processRepair(Player $player, int $cost): void {
        $item = $player->getInventory()->getItemInHand();

        $damage = $item->getDamage();
        if($damage <= 0){
            $player->sendMessage("§aEşyan hasarsız, tamire gerek yok!");
            return;
        }

        $money = EconomyAPI::getInstance()->myMoney($player);

        if($money < $cost){
            $player->sendMessage("§cYeterli paran yok! Tamir için §f{$cost}TL §cgerekiyor.");
            return;
        }

        EconomyAPI::getInstance()->reduceMoney($player, $cost);
        $item->setDamage(0);
        $player->getInventory()->setItemInHand($item);

        $player->sendMessage("§aEşyan başarıyla tamir edildi! Ödenen miktar: §f{$cost}TL.");
    }
}